#pragma once

#include "ofMain.h"
#include "ofxCv.h"
#include "ofxOpenCv.h"
#include "ofxGui.h"

 // set to -1 to not use the enable pin (its optional)

class testApp : public ofBaseApp{

public:

	void setup();
	void update();
	void draw();
    void keyPressed(int key);
    
    
	void runLights(float br[]);
    void sendLights();
    void makeNoise(void);
    void testCom(int val);
    
    

	int val;
	int valInc;

    const static int numLEDs = 30;
	unsigned char br[numLEDs+1];
    float noiseVal[numLEDs];
	unsigned char* pixels;
	int cellSize;
	float cellSizeFl;
	int numPixels;
    int numCellsX, numCellsY;
    bool bReadyToSend;

	int	cameraWidth;
	int	cameraHeight;

	float displayCoeff;
    
    
    //noise Vars
    float noiseAmp, time, timeInc;

	
	int numBoards;
    
    //video stuff
	ofVideoGrabber videoGrabber;
    ofxCv::RunningBackground background;
    ofImage thresholded;
    ofImage regImage;
    
    ofxPanel gui;
    ofxIntSlider backgroundThresh;
    ofxIntSlider minArea;
    ofxIntSlider maxArea;
    ofxIntSlider blurAmount;
    ofxIntSlider erodeAmount;
    ofxIntSlider dilateAmount;
    ofxIntSlider learningTime;
    ofxButton reset;


	
    
    ofSerial	serial;
    
    
    
    
private:
    
    const static int messPerFrame = 100;
    int numIterations;
    int iteration;



	
};
